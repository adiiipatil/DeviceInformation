package com.example.deviceinformation;

import androidx.appcompat.app.AppCompatActivity;

import android.app.appsearch.StorageInfo;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {
    MaterialButton button;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button=findViewById(R.id.button);
        textView=findViewById(R.id.textViewId);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String SERIAL=("SERIAL: " + Build.SERIAL);
                String MODEL=("MODEL:" + Build. MODEL);
                String ID=("ID:" + Build.ID);
                String Manufacture=("Manufacture: " + Build. MANUFACTURER);
                String brand=("brand:"+ Build. BRAND);
                String type=("type: "+ Build. TYPE);
                String user=("user:" + Build.USER);
                String BASE=("BASE:" + Build.VERSION_CODES.BASE);
                String INCREMENTAL= ("INCREMENTAL: " + Build.VERSION. INCREMENTAL);
                String SDK =("SDK: "+ Build.VERSION.SDK);

                String BOARD=("BOARD:" + Build. BOARD);

                String BRAND=("BRAND: " + Build.BRAND);

                String HOST=("HOST:" + Build.HOST);

                String FINGERPRINT=("FINGERPRINT: "+Build. FINGERPRINT);

                String VersionCode=( "Version Code: " + Build.VERSION.RELEASE);
                textView.setText(SERIAL+"\n"+MODEL+"\n"+ID+"\n"+Manufacture+"\n"+brand+"\n"+type+"\n"+user+"\n"+BASE+"\n"+INCREMENTAL+"\n"+SDK+"\n"+BOARD+"\n"+BRAND+"\n"+HOST+"\n"+FINGERPRINT+"\n"+VersionCode);
            }
        });
    }
}